# Straditize Pro - Geological Stratigraphic Pollen Diagram Plotting Script
# Generated automatically by Straditize v2.0 (straditize pro)
if (!requireNamespace('rioja', quietly=TRUE)) install.packages('rioja')
library(rioja)
df <- read.csv('data.csv', check.names=FALSE)
strat.plot(df[-1], yvar=df[[1]], y.rev=TRUE, scale.percent=TRUE, plot.line=TRUE, title='Stratigraphic Pollen Diagram (Straditize Pro)')
