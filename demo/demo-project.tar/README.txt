Straditize Pro - Stratigraphic Project Archive (POSIX UStar .tar)
================================================================

Hierarchy:
manifest.json      - Version and metadata
image/original.png - Original stratigraphic diagram
straditize.json    - Full vector model
data.csv           - Calibrated matrix (Depth in 1st col, unobserved = 0.0)
plot_strat.R       - rioja::strat.plot plotting template
README.txt         - Documentation

SCIENTIFIC NOTICE:
In data.csv, unobserved taxa are strictly 0.0 (never NA).
Add a pseudocount before taking log transformations.
